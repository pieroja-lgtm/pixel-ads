/**
 * Pixel Ads - Lógica de Interactividad Web App
 */

document.addEventListener('DOMContentLoaded', () => {
    // Inicializar íconos Lucide
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // Eventos para la entrada del formulario en vivo
    const bizInput = document.getElementById('biz-input');
    const rubroInput = document.getElementById('rubro-input');

    if (bizInput) {
        bizInput.addEventListener('input', updatePreview);
    }

    if (rubroInput) {
        rubroInput.addEventListener('change', updatePreview);
    }
});

/**
 * Cambia entre las diferentes pestañas del Dashboard
 * @param {string} tabId - ID del contenedor de la pestaña a activar
 * @param {HTMLElement} btn - Botón presionado
 */
function openTab(tabId, btn) {
    // Ocultar todos los contenidos de pestaña
    const contents = document.querySelectorAll('.content-area');
    contents.forEach(content => content.classList.remove('active'));

    // Desactivar todos los botones de pestaña
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(tab => tab.classList.remove('active'));

    // Activar el contenedor y el botón seleccionado
    const selectedTab = document.getElementById(tabId);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }

    if (btn) {
        btn.classList.add('active');
    }
}

/**
 * Selecciona un servicio desde la lista y redirige al simulador/editor
 * @param {string} name - Nombre del servicio
 * @param {number} price - Precio del servicio en Soles (S/)
 */
function chooseService(name, price) {
    const serviceInput = document.getElementById('selected-service-text');
    if (serviceInput) {
        serviceInput.value = `${name} (S/ ${price})`;
    }

    // Cambiar automáticamente a la pestaña del editor
    const editorTabBtn = document.querySelectorAll('.tab-btn')[1];
    if (editorTabBtn) {
        openTab('tab-editor', editorTabBtn);
    }
}

/**
 * Actualiza la vista previa del anuncio en tiempo real según las opciones ingresadas
 */
function updatePreview() {
    const bizInput = document.getElementById('biz-input');
    const rubroInput = document.getElementById('rubro-input');
    const prevNameText = document.getElementById('prev-name-text');
    const prevPromoText = document.getElementById('prev-promo-text');

    const businessName = bizInput && bizInput.value.trim() !== "" 
        ? bizInput.value.trim().toUpperCase() 
        : "TU MARCA AQUÍ";

    if (prevNameText) {
        prevNameText.innerText = businessName;
    }

    // Personalización automática según el rubro seleccionado
    let promoText = "PROMO EXCLUSIVA";
    if (rubroInput) {
        const rubroValue = rubroInput.value;
        if (rubroValue.includes("Gastronomía") || rubroValue.includes("Comida")) {
            promoText = "MENÚ O COMBO 2X1";
        } else if (rubroValue.includes("Moda")) {
            promoText = "NUEVA COLECCIÓN";
        } else if (rubroValue.includes("Salud") || rubroValue.includes("Estética")) {
            promoText = "DESCUENTO EN CONSULTA";
        } else if (rubroValue.includes("Barbería")) {
            promoText = "DESCUENTO EN CORTE";
        }
    }

    if (prevPromoText) {
        prevPromoText.innerText = promoText;
    }
}

/**
 * Genera el mensaje y abre WhatsApp con el pedido detallado, además de mostrar el modal
 */
function submitOrder() {
    const bizInput = document.getElementById('biz-input');
    const rubroInput = document.getElementById('rubro-input');
    const serviceInput = document.getElementById('selected-service-text');

    const empresa = bizInput && bizInput.value.trim() !== "" ? bizInput.value.trim() : "No especificado";
    const rubro = rubroInput ? rubroInput.value : "General";
    const servicio = serviceInput ? serviceInput.value : "Publicación Sencilla (S/ 5)";

    // Configura aquí tu número de teléfono de WhatsApp (código de país + número)
    const whatsappPhone = "51900000000"; 

    // Construcción del mensaje para WhatsApp
    const message = `👋 ¡Hola Pixel Ads! Quisiera solicitar un servicio:\n\n` +
                    `📌 *Empresa:* ${empresa}\n` +
                    `💼 *Rubro:* ${rubro}\n` +
                    `🎨 *Servicio:* ${servicio}\n\n` +
                    `Quedo a la espera de su respuesta. ¡Gracias!`;

    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${whatsappPhone}?text=${encodedMessage}`;

    // Mostrar el modal de confirmación en la app
    const modalBox = document.getElementById('modal-box');
    if (modalBox) {
        modalBox.classList.add('active');
    }

    // Abrir WhatsApp en una nueva pestaña después de un pequeño delay
    setTimeout(() => {
        window.open(whatsappUrl, '_blank');
    }, 800);
}

/**
 * Cierra la ventana emergente o modal
 */
function closeModal() {
    const modalBox = document.getElementById('modal-box');
    if (modalBox) {
        modalBox.classList.remove('active');
    }
}